
  # NoteLoop AI UI Design (Copy)

  This is a code bundle for NoteLoop AI UI Design (Copy). The original project is available at https://www.figma.com/design/VXnKCHh7xbHpFuX9LXoNCx/NoteLoop-AI-UI-Design--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  