
  # NoteLoop AI UI Design

  This is a code bundle for NoteLoop AI UI Design. The original project is available at https://www.figma.com/design/yMHDqlHb7RLJ55RI9vi9Rj/NoteLoop-AI-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  