import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Upload, FileText, Image, FileCode, Check, Loader2, X, Tag, Lock } from 'lucide-react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Input } from './ui/input';

interface UploadHubProps {
  onBack: () => void;
  onUploadComplete?: () => void;
}

interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: string;
  status: 'uploading' | 'processing' | 'complete';
  progress: number;
  tags: string[];
}

const mockProcessedFiles: UploadedFile[] = [
  {
    id: '1',
    name: 'Machine Learning Notes.pdf',
    type: 'pdf',
    size: '2.4 MB',
    status: 'complete',
    progress: 100,
    tags: ['Machine Learning', 'Lecture 3', 'Neural Networks']
  },
  {
    id: '2',
    name: 'Chemistry Lab Report.docx',
    type: 'docx',
    size: '1.8 MB',
    status: 'complete',
    progress: 100,
    tags: ['Chemistry', 'Lab 5', 'Organic']
  }
];

export function UploadHub({ onBack, onUploadComplete }: UploadHubProps) {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>(mockProcessedFiles);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState(0);
  const [loginModal, setLoginModal] = useState<string | null>(null);

  const processingSteps = [
    'Reading notes...',
    'Extracting concepts...',
    'Generating clips...',
    'Complete!'
  ];

  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const newFile: UploadedFile = {
      id: Date.now().toString(),
      name: files[0].name,
      type: files[0].name.split('.').pop() || 'file',
      size: `${(files[0].size / 1024 / 1024).toFixed(1)} MB`,
      status: 'uploading',
      progress: 0,
      tags: []
    };

    setUploadedFiles([newFile, ...uploadedFiles]);
    setIsProcessing(true);
    setProcessingStep(0);

    // Simulate upload and processing
    let progress = 0;
    let step = 0;
    const interval = setInterval(() => {
      progress += 10;
      if (progress > 100) {
        clearInterval(interval);
        setUploadedFiles(files => 
          files.map(f => 
            f.id === newFile.id 
              ? { ...f, status: 'complete', progress: 100, tags: ['Auto-tagged', 'New Topic'] }
              : f
          )
        );
        setIsProcessing(false);
        return;
      }

      if (progress % 33 === 0 && step < 3) {
        step++;
        setProcessingStep(step);
      }

      setUploadedFiles(files => 
        files.map(f => 
          f.id === newFile.id 
            ? { ...f, progress, status: progress > 30 ? 'processing' : 'uploading' }
            : f
        )
      );
    }, 300);
  };

  const getFileIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pdf': return FileText;
      case 'docx': case 'doc': return FileCode;
      case 'png': case 'jpg': case 'jpeg': return Image;
      default: return FileText;
    }
  };

  const handleServiceLogin = (serviceName: string) => {
    // This would normally trigger OAuth flow
    console.log(`Logging in to ${serviceName}...`);
    setTimeout(() => {
      setLoginModal(null);
      // Here you would handle the actual OAuth connection
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-slate-900/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button
            onClick={onBack}
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/10 rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="text-white">Create Your Loop</div>
          <div className="w-10" />
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Upload Area */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`relative rounded-3xl border-2 border-dashed transition-all ${
            isDragging
              ? 'border-blue-400 bg-blue-500/10'
              : 'border-slate-600 hover:border-slate-500'
          }`}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            handleFileUpload(e.dataTransfer.files);
          }}
        >
          <div className="p-12 text-center">
            <motion.div
              className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-emerald-400 flex items-center justify-center mx-auto mb-6"
              animate={{
                scale: isDragging ? 1.1 : 1,
              }}
            >
              <Upload className="w-10 h-10 text-white" />
            </motion.div>

            <h3 className="text-2xl text-white mb-2">Upload Notes or Slides</h3>
            <p className="text-slate-400 mb-6">
              Drag and drop files here or click to browse
            </p>

            <div className="flex flex-wrap justify-center gap-2 mb-6">
              {['PDF', 'DOCX', 'PPTX', 'PNG', 'JPG'].map((format) => (
                <Badge
                  key={format}
                  variant="secondary"
                  className="bg-white/10 text-slate-300 border-white/20"
                >
                  {format}
                </Badge>
              ))}
            </div>

            <input
              type="file"
              id="file-upload"
              className="hidden"
              accept=".pdf,.docx,.pptx,.png,.jpg,.jpeg"
              onChange={(e) => handleFileUpload(e.target.files)}
            />
            <Button
              onClick={() => document.getElementById('file-upload')?.click()}
              className="bg-gradient-to-r from-blue-500 to-emerald-400 hover:from-blue-600 hover:to-emerald-500 text-white rounded-full px-8"
            >
              Choose Files
            </Button>
          </div>
        </motion.div>

        {/* Processing Animation */}
        {isProcessing && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                >
                  <Loader2 className="w-5 h-5 text-blue-400" />
                </motion.div>
                <span className="text-white">{processingSteps[processingStep]}</span>
              </div>
            </div>
            <Progress value={(processingStep / processingSteps.length) * 100} />
          </motion.div>
        )}

        {/* Uploaded Files */}
        {uploadedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xl text-white">Your Uploads</h3>
              <Button
                onClick={onUploadComplete}
                className="bg-gradient-to-r from-blue-500 to-emerald-400 hover:from-blue-600 hover:to-emerald-500 text-white rounded-full"
              >
                Generate Learning Feed
              </Button>
            </div>

            <div className="space-y-3">
              {uploadedFiles.map((file) => (
                <FileCard key={file.id} file={file} />
              ))}
            </div>
          </motion.div>
        )}

        {/* Quick Import Options */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6"
        >
          <h3 className="text-lg text-white mb-4">Quick Import</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              { name: 'Google Drive', icon: '📁' },
              { name: 'Notion', icon: '📝' },
              { name: 'Canvas', icon: '🎓' }
            ].map((service) => (
              <motion.button
                key={service.name}
                onClick={() => setLoginModal(service.name)}
                className="p-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-left"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="text-2xl mb-2">{service.icon}</div>
                <div className="text-white text-sm">{service.name}</div>
              </motion.button>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Login Modal */}
      <AnimatePresence>
        {loginModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setLoginModal(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-800 border border-white/10 rounded-3xl p-8 max-w-md w-full"
            >
              <div className="text-center">
                {/* Icon */}
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", delay: 0.1 }}
                  className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-emerald-400 flex items-center justify-center mx-auto mb-6"
                >
                  <Lock className="w-10 h-10 text-white" />
                </motion.div>

                <h2 className="text-2xl text-white mb-2">Connect {loginModal}</h2>
                <p className="text-slate-400 text-sm mb-8">
                  Sign in to your {loginModal} account to import your notes
                </p>

                {/* Login Form */}
                <div className="space-y-4 mb-6">
                  <Input
                    type="email"
                    placeholder="Email"
                    className="bg-white/5 border-white/10 text-white placeholder:text-slate-500 rounded-xl h-12"
                  />
                  <Input
                    type="password"
                    placeholder="Password"
                    className="bg-white/5 border-white/10 text-white placeholder:text-slate-500 rounded-xl h-12"
                  />
                </div>

                <div className="space-y-3">
                  <Button
                    onClick={() => handleServiceLogin(loginModal)}
                    className="w-full bg-gradient-to-r from-blue-500 to-emerald-400 hover:from-blue-600 hover:to-emerald-500 text-white rounded-full h-12"
                  >
                    Connect {loginModal}
                  </Button>
                  <Button
                    onClick={() => setLoginModal(null)}
                    variant="ghost"
                    className="w-full text-slate-400 hover:text-white hover:bg-white/5 rounded-full h-12"
                  >
                    Cancel
                  </Button>
                </div>

                <p className="text-xs text-slate-500 mt-6">
                  We'll only access your files with your permission
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

interface FileCardProps {
  file: UploadedFile;
}

function FileCard({ file }: FileCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [tags, setTags] = useState(file.tags);
  const [newTag, setNewTag] = useState('');
  const Icon = getFileIcon(file.type);

  const addTag = () => {
    if (newTag && !tags.includes(newTag)) {
      setTags([...tags, newTag]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-4 hover:bg-white/10 transition-colors"
    >
      <div className="flex items-start gap-4">
        {/* File Icon */}
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-emerald-400 flex items-center justify-center flex-shrink-0">
          <Icon className="w-6 h-6 text-white" />
        </div>

        {/* File Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <h4 className="text-white truncate">{file.name}</h4>
              <p className="text-sm text-slate-400">{file.size}</p>
            </div>
            {file.status === 'complete' && (
              <div className="w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center flex-shrink-0">
                <Check className="w-4 h-4 text-white" />
              </div>
            )}
          </div>

          {/* Progress Bar */}
          {file.status !== 'complete' && (
            <div className="mb-3">
              <Progress value={file.progress} className="h-1" />
              <p className="text-xs text-slate-400 mt-1">
                {file.status === 'uploading' ? 'Uploading...' : 'Processing...'}
              </p>
            </div>
          )}

          {/* Tags */}
          {file.status === 'complete' && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                {tags.map((tag) => (
                  <Badge
                    key={tag}
                    className="bg-blue-500/20 text-blue-300 border-blue-500/30 hover:bg-blue-500/30 group"
                  >
                    <Tag className="w-3 h-3 mr-1" />
                    {tag}
                    <button
                      onClick={() => removeTag(tag)}
                      className="ml-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="text-xs text-slate-400 hover:text-white transition-colors"
                >
                  + Add tag
                </button>
              </div>

              {isEditing && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="flex gap-2"
                >
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addTag()}
                    placeholder="Enter tag name"
                    className="bg-white/5 border-white/10 text-white"
                  />
                  <Button
                    onClick={addTag}
                    size="sm"
                    className="bg-blue-500 hover:bg-blue-600 text-white"
                  >
                    Add
                  </Button>
                </motion.div>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function getFileIcon(type: string) {
  switch (type.toLowerCase()) {
    case 'pdf': return FileText;
    case 'docx': case 'doc': return FileCode;
    case 'png': case 'jpg': case 'jpeg': return Image;
    default: return FileText;
  }
}
