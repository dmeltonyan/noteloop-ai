import { useState, useRef, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { Heart, RotateCcw, Settings, MessageCircle, Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { LearningContent } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface MainFeedProps {
  onContentSelect: (content: LearningContent) => void;
  userLevel: number;
}

const mockContent: LearningContent[] = [
  {
    id: '1',
    title: 'Neural Networks — Concept 2 of 5',
    topic: 'Machine Learning',
    level: 'i+1',
    duration: 60,
    thumbnail: 'https://images.unsplash.com/photo-1760900199593-381d2716a970?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXVyYWwlMjBuZXR3b3JrcyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYxNjg2NjYxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    progress: 0,
    difficulty: 'i+1'
  },
  {
    id: '2',
    title: 'Organic Chemistry Basics',
    topic: 'Chemistry',
    level: 'i+1',
    duration: 45,
    thumbnail: 'https://images.unsplash.com/photo-1682391427624-61a45b5c7797?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVtaXN0cnklMjBtb2xlY3VsZXMlMjBzY2llbmNlfGVufDF8fHx8MTc2MTY4NjY2Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    progress: 30,
    difficulty: 'i+1'
  },
  {
    id: '3',
    title: 'Ancient Rome — Rise and Fall',
    topic: 'History',
    level: 'i',
    duration: 55,
    thumbnail: 'https://images.unsplash.com/photo-1717606344894-66e5696bcd18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXN0b3J5JTIwYW5jaWVudCUyMGNpdmlsaXphdGlvbnxlbnwxfHx8fDE3NjE2NDI5ODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    progress: 0,
    difficulty: 'i'
  },
  {
    id: '4',
    title: 'Calculus: Derivatives Explained',
    topic: 'Mathematics',
    level: 'i+2',
    duration: 50,
    thumbnail: 'https://images.unsplash.com/photo-1635372722656-389f87a941b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXRoZW1hdGljcyUyMGVxdWF0aW9uc3xlbnwxfHx8fDE3NjE2NTY4MTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    progress: 0,
    difficulty: 'i+2'
  },
  {
    id: '5',
    title: 'Cell Division & Mitosis',
    topic: 'Biology',
    level: 'i+1',
    duration: 40,
    thumbnail: 'https://images.unsplash.com/photo-1636386689060-37d233b5d345?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaW9sb2d5JTIwY2VsbHMlMjBtaWNyb3Njb3BlfGVufDF8fHx8MTc2MTY0Mjk4NHww&ixlib=rb-4.1.0&q=80&w=1080',
    progress: 75,
    difficulty: 'i+1'
  },
  {
    id: '6',
    title: 'Quantum Mechanics Intro',
    topic: 'Physics',
    level: 'i+2',
    duration: 65,
    thumbnail: 'https://images.unsplash.com/photo-1760900199593-381d2716a970?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXVyYWwlMjBuZXR3b3JrcyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzYxNjg2NjYxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    progress: 0,
    difficulty: 'i+2'
  }
];

export function MainFeed({ onContentSelect, userLevel }: MainFeedProps) {
  const [contents, setContents] = useState(mockContent);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [mutedId, setMutedId] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setContents([...mockContent].sort(() => Math.random() - 0.5));
      setIsRefreshing(false);
    }, 1500);
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const scrollPosition = container.scrollTop;
    const itemHeight = container.scrollHeight / contents.length;
    const index = Math.round(scrollPosition / itemHeight);
    setCurrentIndex(index);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'i': return 'from-emerald-500 to-teal-500';
      case 'i+1': return 'from-blue-500 to-purple-500';
      case 'i+2': return 'from-purple-500 to-pink-500';
      default: return 'from-blue-500 to-emerald-400';
    }
  };

  return (
    <div className="h-screen overflow-hidden relative">
      {/* Top bar with level indicator */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 bg-gradient-to-b from-slate-900/80 to-transparent backdrop-blur-sm">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <motion.div
            className="px-4 py-2 rounded-full bg-gradient-to-r from-blue-500 to-emerald-400 text-white"
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            Level i+{userLevel}
          </motion.div>
          <div className="text-slate-300 text-sm">Swipe to explore</div>
        </div>
      </div>

      {/* Pull to refresh indicator */}
      {isRefreshing && (
        <div className="absolute top-20 left-0 right-0 z-20 flex justify-center">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white"
          >
            <div className="flex items-center gap-2">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              >
                <RotateCcw className="w-4 h-4" />
              </motion.div>
              Generating new i+1 videos...
            </div>
          </motion.div>
        </div>
      )}

      {/* Main scroll container */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="h-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {contents.map((content, index) => (
          <div
            key={content.id}
            className="h-screen snap-start snap-always flex items-center justify-center p-4 relative"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.5 }}
              className="w-full max-w-md h-[85vh] rounded-3xl overflow-hidden relative cursor-pointer"
              onClick={() => onContentSelect(content)}
            >
              {/* Background image with gradient overlay */}
              <div className="absolute inset-0">
                <ImageWithFallback
                  src={content.thumbnail}
                  alt={content.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-slate-900/90" />
              </div>

              {/* Glassmorphism card overlay */}
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-slate-900/60 backdrop-blur-[2px]" />

              {/* Content info */}
              <div className="absolute bottom-0 left-0 right-0 p-6 space-y-4">
                {/* Difficulty badge */}
                <motion.div
                  className={`inline-block px-4 py-2 rounded-full bg-gradient-to-r ${getDifficultyColor(content.difficulty)} text-white text-sm`}
                  whileHover={{ scale: 1.05 }}
                >
                  {content.difficulty}
                </motion.div>

                {/* Title and topic */}
                <div>
                  <h3 className="text-2xl text-white mb-1">{content.title}</h3>
                  <p className="text-slate-300">{content.topic}</p>
                </div>

                {/* Progress bar */}
                {content.progress > 0 && (
                  <div className="w-full bg-white/20 rounded-full h-1 overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-blue-500 to-emerald-400"
                      initial={{ width: 0 }}
                      animate={{ width: `${content.progress}%` }}
                      transition={{ duration: 1 }}
                    />
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex items-center justify-around pt-4">
                  <ActionButton
                    icon={Heart}
                    label="I got it"
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  />
                  <ActionButton
                    icon={RotateCcw}
                    label="Repeat"
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  />
                  <ActionButton
                    icon={Settings}
                    label="Explain"
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  />
                  <ActionButton
                    icon={MessageCircle}
                    label="Notes"
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  />
                </div>

                {/* Duration */}
                <div className="flex items-center justify-center gap-2 text-slate-400 text-sm pt-2">
                  <Play className="w-4 h-4" />
                  {content.duration}s
                </div>
              </div>
            </motion.div>
          </div>
        ))}
      </div>

      {/* Progress indicators */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 z-20 space-y-2">
        {contents.map((_, index) => (
          <div
            key={index}
            className={`w-1 h-8 rounded-full transition-all ${
              index === currentIndex
                ? 'bg-gradient-to-b from-blue-500 to-emerald-400 h-12'
                : 'bg-white/30'
            }`}
          />
        ))}
      </div>
    </div>
  );
}

interface ActionButtonProps {
  icon: React.ElementType;
  label: string;
  onClick: (e: React.MouseEvent) => void;
}

function ActionButton({ icon: Icon, label, onClick }: ActionButtonProps) {
  return (
    <motion.button
      onClick={onClick}
      className="flex flex-col items-center gap-1 text-white"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
    >
      <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center hover:bg-white/20 transition-colors">
        <Icon className="w-5 h-5" />
      </div>
      <span className="text-xs text-slate-300">{label}</span>
    </motion.button>
  );
}
