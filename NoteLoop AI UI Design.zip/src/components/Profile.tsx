import { useState } from 'react';
import { motion } from 'motion/react';
import { User, Settings, Star, Upload, Heart, Clock, Moon, Sun, Bell, Lock, LogOut } from 'lucide-react';
import { Card } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';

interface ProfileProps {
  userLevel: number;
}

const userStats = {
  totalXP: 2080,
  uploadsCount: 12,
  favoritesCount: 48,
  totalTime: 145
};

const mockUploads = [
  { id: '1', name: 'Machine Learning Notes.pdf', date: 'Oct 20, 2025', topics: 5 },
  { id: '2', name: 'Chemistry Lab Report.docx', date: 'Oct 18, 2025', topics: 3 },
  { id: '3', name: 'History Essay Notes.pdf', date: 'Oct 15, 2025', topics: 4 }
];

const mockFavorites = [
  { id: '1', title: 'Neural Networks Basics', topic: 'ML', duration: '60s' },
  { id: '2', title: 'Organic Chemistry 101', topic: 'Chemistry', duration: '45s' },
  { id: '3', title: 'Ancient Rome History', topic: 'History', duration: '55s' },
  { id: '4', title: 'Calculus Derivatives', topic: 'Math', duration: '50s' }
];

export function Profile({ userLevel }: ProfileProps) {
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [focusMode, setFocusMode] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-24 pt-6">
      <div className="max-w-4xl mx-auto px-4 space-y-6">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="bg-gradient-to-br from-blue-500/20 to-emerald-500/20 backdrop-blur-sm border-blue-500/30 p-8">
            <div className="flex flex-col md:flex-row items-center gap-6">
              {/* Avatar */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="relative"
              >
                <Avatar className="w-24 h-24 border-4 border-white/20">
                  <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white text-3xl">
                    ME
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-2 -right-2 px-3 py-1 rounded-full bg-gradient-to-r from-blue-500 to-emerald-400 text-white text-sm">
                  i+{userLevel}
                </div>
              </motion.div>

              {/* User Info */}
              <div className="flex-1 text-center md:text-left">
                <h1 className="text-3xl text-white mb-2">Your Profile</h1>
                <p className="text-slate-300 mb-4">Level {userLevel} Learner • {userStats.totalXP} XP</p>
                <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                  <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                    ⚡ 12 Day Streak
                  </Badge>
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                    🧠 Brain Builder
                  </Badge>
                  <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30">
                    🎯 Focus Master
                  </Badge>
                </div>
              </div>

              {/* Edit Button */}
              <Button
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10"
              >
                <Settings className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: Star, label: 'Total XP', value: userStats.totalXP.toLocaleString(), color: 'from-yellow-500 to-orange-500' },
            { icon: Upload, label: 'Uploads', value: userStats.uploadsCount, color: 'from-blue-500 to-cyan-500' },
            { icon: Heart, label: 'Favorites', value: userStats.favoritesCount, color: 'from-pink-500 to-red-500' },
            { icon: Clock, label: 'Study Time', value: `${userStats.totalTime}h`, color: 'from-emerald-500 to-teal-500' }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.05 }}
            >
              <Card className="bg-white/5 backdrop-blur-sm border-white/10 p-4 text-center">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mx-auto mb-2`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <div className="text-2xl text-white mb-1">{stat.value}</div>
                <div className="text-xs text-slate-400">{stat.label}</div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Tabs */}
        <Tabs defaultValue="uploads" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white/5 border border-white/10">
            <TabsTrigger value="uploads">
              <Upload className="w-4 h-4 mr-2" />
              Uploads
            </TabsTrigger>
            <TabsTrigger value="favorites">
              <Heart className="w-4 h-4 mr-2" />
              Favorites
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* Uploads Tab */}
          <TabsContent value="uploads" className="mt-6 space-y-3">
            {mockUploads.map((upload, index) => (
              <motion.div
                key={upload.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-white/5 backdrop-blur-sm border-white/10 p-4 hover:bg-white/10 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h4 className="text-white mb-1">{upload.name}</h4>
                      <div className="flex items-center gap-4 text-sm text-slate-400">
                        <span>{upload.date}</span>
                        <span>•</span>
                        <span>{upload.topics} topics generated</span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-slate-400 hover:text-white"
                    >
                      View
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </TabsContent>

          {/* Favorites Tab */}
          <TabsContent value="favorites" className="mt-6 space-y-3">
            {mockFavorites.map((favorite, index) => (
              <motion.div
                key={favorite.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-white/5 backdrop-blur-sm border-white/10 p-4 hover:bg-white/10 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-emerald-400 flex items-center justify-center flex-shrink-0">
                        <Heart className="w-6 h-6 text-white fill-white" />
                      </div>
                      <div>
                        <h4 className="text-white mb-1">{favorite.title}</h4>
                        <div className="flex items-center gap-3 text-sm">
                          <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                            {favorite.topic}
                          </Badge>
                          <span className="text-slate-400">{favorite.duration}</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-slate-400 hover:text-white"
                    >
                      Play
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="mt-6">
            <Card className="bg-white/5 backdrop-blur-sm border-white/10 divide-y divide-white/10">
              {/* Appearance */}
              <div className="p-6 space-y-4">
                <h3 className="text-white flex items-center gap-2 mb-4">
                  <Sun className="w-5 h-5" />
                  Appearance
                </h3>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-white text-sm mb-1">Dark Mode</div>
                    <div className="text-slate-400 text-xs">Use dark theme</div>
                  </div>
                  <Switch checked={darkMode} onCheckedChange={setDarkMode} />
                </div>
              </div>

              <Separator className="bg-white/10" />

              {/* Notifications */}
              <div className="p-6 space-y-4">
                <h3 className="text-white flex items-center gap-2 mb-4">
                  <Bell className="w-5 h-5" />
                  Notifications
                </h3>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-white text-sm mb-1">Push Notifications</div>
                    <div className="text-slate-400 text-xs">Receive study reminders</div>
                  </div>
                  <Switch checked={notifications} onCheckedChange={setNotifications} />
                </div>
              </div>

              <Separator className="bg-white/10" />

              {/* Focus Mode (Easter Egg) */}
              <div className="p-6 space-y-4">
                <h3 className="text-white flex items-center gap-2 mb-4">
                  <Moon className="w-5 h-5" />
                  Focus Mode 🎯
                </h3>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-white text-sm mb-1">Enable Focus Mode</div>
                    <div className="text-slate-400 text-xs">25 min Pomodoro session</div>
                  </div>
                  <Switch checked={focusMode} onCheckedChange={setFocusMode} />
                </div>
                {focusMode && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/30"
                  >
                    <div className="text-purple-300 text-sm">
                      🎉 Easter Egg Unlocked! Focus Mode will silence all notifications for 25 minutes.
                    </div>
                  </motion.div>
                )}
              </div>

              <Separator className="bg-white/10" />

              {/* Privacy & Security */}
              <div className="p-6 space-y-4">
                <h3 className="text-white flex items-center gap-2 mb-4">
                  <Lock className="w-5 h-5" />
                  Privacy & Security
                </h3>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-slate-300 hover:text-white hover:bg-white/5"
                >
                  Manage Subscription
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-slate-300 hover:text-white hover:bg-white/5"
                >
                  Privacy Settings
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-slate-300 hover:text-white hover:bg-white/5"
                >
                  Data & Storage
                </Button>
              </div>

              <Separator className="bg-white/10" />

              {/* Account */}
              <div className="p-6">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-500/10"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Log Out
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
