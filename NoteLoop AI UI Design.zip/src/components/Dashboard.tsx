import { motion } from 'motion/react';
import { TrendingUp, Clock, Zap, Award, Brain, Target, Calendar, Flame } from 'lucide-react';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';

interface DashboardProps {
  userLevel: number;
}

const mockStats = {
  averageSession: 7,
  comprehensionIncrease: 14,
  wordsLearned: 320,
  streakDays: 12,
  topicsCompleted: 8,
  totalTime: 145
};

const learningCurve = [
  { level: 'i', topics: 15, mastery: 95 },
  { level: 'i+1', topics: 12, mastery: 78 },
  { level: 'i+2', topics: 5, mastery: 42 }
];

const achievements = [
  { id: '1', name: '🔥 12 Day Streak', description: 'Keep the fire burning!', unlocked: true },
  { id: '2', name: '🧠 Brain Builder', description: 'Completed 100 lessons', unlocked: true },
  { id: '3', name: '⚡ Focus Master', description: 'Studied for 1 hour straight', unlocked: true },
  { id: '4', name: '🎯 Perfect Week', description: 'Study 7 days in a row', unlocked: false },
  { id: '5', name: '📚 Knowledge Guru', description: 'Master 50 topics', unlocked: false },
  { id: '6', name: '🚀 Speed Learner', description: 'Complete 20 lessons in a day', unlocked: false }
];

const recentActivity = [
  { date: 'Today', topics: ['Neural Networks', 'Calculus'], time: 23 },
  { date: 'Yesterday', topics: ['Chemistry', 'History'], time: 18 },
  { date: '2 days ago', topics: ['Biology', 'Physics'], time: 31 }
];

export function Dashboard({ userLevel }: DashboardProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-24 pt-6">
      <div className="max-w-6xl mx-auto px-4 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-3xl text-white mb-2">Learning Analytics</h1>
          <p className="text-slate-400">Track your progress and achievements</p>
        </motion.div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            icon={Clock}
            label="Avg Session"
            value={`${mockStats.averageSession} min`}
            color="from-blue-500 to-cyan-500"
            delay={0}
          />
          <StatCard
            icon={TrendingUp}
            label="Comprehension"
            value={`+${mockStats.comprehensionIncrease}%`}
            color="from-emerald-500 to-teal-500"
            delay={0.1}
          />
          <StatCard
            icon={Brain}
            label="Words Learned"
            value={mockStats.wordsLearned.toString()}
            color="from-purple-500 to-pink-500"
            delay={0.2}
          />
          <StatCard
            icon={Flame}
            label="Streak"
            value={`${mockStats.streakDays} days`}
            color="from-orange-500 to-red-500"
            delay={0.3}
          />
        </div>

        {/* Learning Curve Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-white/5 backdrop-blur-sm border-white/10 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl text-white">Your Learning Curve</h2>
              <Badge className="bg-gradient-to-r from-blue-500 to-emerald-400 text-white border-0">
                Level i+{userLevel}
              </Badge>
            </div>

            <div className="space-y-4">
              {learningCurve.map((level, index) => (
                <motion.div
                  key={level.level}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="space-y-2"
                >
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-3">
                      <div className={`px-3 py-1 rounded-full bg-gradient-to-r ${
                        level.level === 'i' ? 'from-emerald-500 to-teal-500' :
                        level.level === 'i+1' ? 'from-blue-500 to-purple-500' :
                        'from-purple-500 to-pink-500'
                      } text-white text-xs`}>
                        {level.level}
                      </div>
                      <span className="text-slate-300">{level.topics} topics</span>
                    </div>
                    <span className="text-white">{level.mastery}% mastery</span>
                  </div>
                  <div className="relative">
                    <Progress value={level.mastery} className="h-2" />
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-6 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
              <div className="flex items-start gap-3">
                <Target className="w-5 h-5 text-blue-400 mt-1" />
                <div>
                  <div className="text-white text-sm mb-1">i→i+1→i+2 Progression</div>
                  <div className="text-slate-400 text-xs">
                    You're advancing through difficulty levels at an optimal pace. Keep up the great work!
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="bg-white/5 backdrop-blur-sm border-white/10 p-6">
            <div className="flex items-center gap-2 mb-6">
              <Award className="w-6 h-6 text-yellow-400" />
              <h2 className="text-xl text-white">Achievements</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.7 + index * 0.05 }}
                  className={`p-4 rounded-xl border transition-all ${
                    achievement.unlocked
                      ? 'bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-yellow-500/30'
                      : 'bg-white/5 border-white/10 opacity-50'
                  }`}
                >
                  <div className="text-3xl mb-2">{achievement.name.split(' ')[0]}</div>
                  <div className="text-white text-sm mb-1">
                    {achievement.name.split(' ').slice(1).join(' ')}
                  </div>
                  <div className="text-slate-400 text-xs">{achievement.description}</div>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <Card className="bg-white/5 backdrop-blur-sm border-white/10 p-6">
            <div className="flex items-center gap-2 mb-6">
              <Calendar className="w-6 h-6 text-emerald-400" />
              <h2 className="text-xl text-white">Recent Activity</h2>
            </div>

            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.9 + index * 0.1 }}
                  className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <div className="flex-1">
                    <div className="text-white mb-2">{activity.date}</div>
                    <div className="flex gap-2 flex-wrap">
                      {activity.topics.map((topic) => (
                        <Badge
                          key={topic}
                          variant="secondary"
                          className="bg-blue-500/20 text-blue-300 border-blue-500/30"
                        >
                          {topic}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <div className="text-emerald-400">{activity.time} min</div>
                    <div className="text-xs text-slate-400">study time</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Weekly Goal */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
        >
          <Card className="bg-gradient-to-br from-blue-500/10 to-emerald-500/10 backdrop-blur-sm border-blue-500/20 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl text-white mb-1">Weekly Goal</h3>
                <p className="text-slate-400 text-sm">145 / 180 minutes</p>
              </div>
              <div className="text-3xl">🎯</div>
            </div>
            <Progress value={(mockStats.totalTime / 180) * 100} className="h-3" />
            <p className="text-slate-400 text-sm mt-3">
              35 more minutes to reach your weekly goal!
            </p>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}

interface StatCardProps {
  icon: React.ElementType;
  label: string;
  value: string;
  color: string;
  delay: number;
}

function StatCard({ icon: Icon, label, value, color, delay }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card className="bg-white/5 backdrop-blur-sm border-white/10 p-4 hover:bg-white/10 transition-colors">
        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-3`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <div className="text-2xl text-white mb-1">{value}</div>
        <div className="text-xs text-slate-400">{label}</div>
      </Card>
    </motion.div>
  );
}
