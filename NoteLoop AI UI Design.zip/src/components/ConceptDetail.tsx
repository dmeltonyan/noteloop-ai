import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Play, Pause, Volume2, VolumeX, RotateCw, Sparkles, TrendingUp, FileText } from 'lucide-react';
import { LearningContent } from '../App';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ConceptDetailProps {
  content: LearningContent | null;
  onBack: () => void;
}

const mockTranscript = [
  { time: 0, text: "Let's explore neural networks, a fundamental concept in machine learning.", highlight: ["neural networks", "machine learning"] },
  { time: 5, text: "A neural network is inspired by the human brain's structure.", highlight: ["human brain"] },
  { time: 10, text: "It consists of layers of interconnected nodes, or neurons.", highlight: ["nodes", "neurons"] },
  { time: 15, text: "Each connection has a weight that adjusts during training.", highlight: ["weight", "training"] },
  { time: 20, text: "This allows the network to learn patterns and make predictions.", highlight: ["learn patterns", "predictions"] }
];

export function ConceptDetail({ content, onBack }: ConceptDetailProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [difficulty, setDifficulty] = useState(1);
  const [showTranscript, setShowTranscript] = useState(false);

  if (!content) return null;

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    if (!isPlaying) {
      const interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= content.duration) {
            clearInterval(interval);
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
  };

  const getCurrentTranscript = () => {
    return mockTranscript.find((t, i) => {
      const nextTime = mockTranscript[i + 1]?.time || content.duration;
      return currentTime >= t.time && currentTime < nextTime;
    });
  };

  const difficultyLabels = ["Simple", "Standard", "Advanced"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-slate-900/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button
            onClick={onBack}
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/10 rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="text-center flex-1">
            <div className="text-white">{content.title}</div>
            <div className="text-sm text-slate-400">{content.topic}</div>
          </div>
          <div className="w-10" />
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Video Player */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative rounded-3xl overflow-hidden aspect-video bg-slate-950"
        >
          <ImageWithFallback
            src={content.thumbnail}
            alt={content.title}
            className="w-full h-full object-cover"
          />
          
          {/* Play overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-slate-900/60 flex items-center justify-center">
            <motion.button
              onClick={handlePlayPause}
              className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm border-2 border-white/40 flex items-center justify-center hover:bg-white/30 transition-colors"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {isPlaying ? (
                <Pause className="w-8 h-8 text-white" />
              ) : (
                <Play className="w-8 h-8 text-white ml-1" />
              )}
            </motion.button>
          </div>

          {/* Video controls */}
          <div className="absolute bottom-0 left-0 right-0 p-6 space-y-3">
            {/* Progress bar */}
            <div className="w-full bg-white/20 rounded-full h-1 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-blue-500 to-emerald-400"
                style={{ width: `${(currentTime / content.duration) * 100}%` }}
              />
            </div>

            {/* Controls row */}
            <div className="flex items-center justify-between text-white">
              <span className="text-sm">
                {Math.floor(currentTime / 60)}:{(currentTime % 60).toString().padStart(2, '0')} / {Math.floor(content.duration / 60)}:{(content.duration % 60).toString().padStart(2, '0')}
              </span>
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center hover:bg-white/20"
              >
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Difficulty badge */}
          <div className="absolute top-4 right-4">
            <div className="px-4 py-2 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm">
              {content.difficulty}
            </div>
          </div>
        </motion.div>

        {/* Difficulty Slider */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-white">
              <TrendingUp className="w-5 h-5" />
              <span>Adaptive Difficulty</span>
            </div>
            <span className="text-emerald-400">{difficultyLabels[difficulty]}</span>
          </div>
          <Slider
            value={[difficulty]}
            onValueChange={(value) => setDifficulty(value[0])}
            max={2}
            step={1}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-slate-400 mt-2">
            <span>Low</span>
            <span>Medium</span>
            <span>High</span>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-3 gap-3"
        >
          <ActionCard
            icon={RotateCw}
            label="Rephrase"
            description="Say it differently"
            gradient="from-blue-500 to-cyan-500"
          />
          <ActionCard
            icon={Sparkles}
            label="Simplify"
            description="Make it easier"
            gradient="from-emerald-500 to-teal-500"
          />
          <ActionCard
            icon={TrendingUp}
            label="Challenge"
            description="Go deeper"
            gradient="from-purple-500 to-pink-500"
          />
        </motion.div>

        {/* Tabs for Transcript and Flashcards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Tabs defaultValue="transcript" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-white/5 border border-white/10">
              <TabsTrigger value="transcript">Transcript</TabsTrigger>
              <TabsTrigger value="notes">Key Points</TabsTrigger>
            </TabsList>
            <TabsContent value="transcript" className="mt-4">
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 space-y-4 max-h-96 overflow-y-auto">
                {mockTranscript.map((item, index) => {
                  const current = getCurrentTranscript();
                  const isCurrent = current?.time === item.time;
                  
                  return (
                    <motion.div
                      key={index}
                      className={`p-4 rounded-xl transition-all ${
                        isCurrent
                          ? 'bg-gradient-to-r from-blue-500/20 to-emerald-400/20 border border-blue-500/30'
                          : 'bg-white/5'
                      }`}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <div className="flex items-start gap-3">
                        <span className="text-xs text-slate-400 mt-1 min-w-[40px]">
                          {Math.floor(item.time / 60)}:{(item.time % 60).toString().padStart(2, '0')}
                        </span>
                        <p className="text-slate-200">
                          {item.text.split(' ').map((word, i) => {
                            const isHighlight = item.highlight.some(h => word.toLowerCase().includes(h.toLowerCase()));
                            return (
                              <span
                                key={i}
                                className={isHighlight ? 'text-emerald-400 font-medium' : ''}
                              >
                                {word}{' '}
                              </span>
                            );
                          })}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </TabsContent>
            <TabsContent value="notes" className="mt-4">
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 space-y-3">
                {["Neural networks mimic brain structure", "Consists of interconnected nodes (neurons)", "Weights adjust during training process", "Learns patterns to make predictions"].map((note, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <div className="w-2 h-2 rounded-full bg-gradient-to-r from-blue-500 to-emerald-400 mt-2" />
                    <span className="text-slate-200">{note}</span>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}

interface ActionCardProps {
  icon: React.ElementType;
  label: string;
  description: string;
  gradient: string;
}

function ActionCard({ icon: Icon, label, description, gradient }: ActionCardProps) {
  return (
    <motion.button
      className="p-4 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-white/20 transition-all text-left"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center mb-3`}>
        <Icon className="w-5 h-5 text-white" />
      </div>
      <div className="text-white text-sm mb-1">{label}</div>
      <div className="text-slate-400 text-xs">{description}</div>
    </motion.button>
  );
}
