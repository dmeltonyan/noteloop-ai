import { useState, useEffect } from 'react';
import { OnboardingFlow } from './components/OnboardingFlow';
import { MainFeed } from './components/MainFeed';
import { ConceptDetail } from './components/ConceptDetail';
import { FlashcardsView } from './components/FlashcardsView';
import { UploadHub } from './components/UploadHub';
import { Dashboard } from './components/Dashboard';
import { SocialLoops } from './components/SocialLoops';
import { Profile } from './components/Profile';
import { BottomNav } from './components/BottomNav';
import { AdaptiveLearningExplainer } from './components/AdaptiveLearningExplainer';

export type Screen = 'onboarding' | 'feed' | 'concept' | 'flashcards' | 'upload' | 'dashboard' | 'social' | 'profile' | 'explainer';

export interface LearningContent {
  id: string;
  title: string;
  topic: string;
  level: string;
  duration: number;
  thumbnail: string;
  progress: number;
  difficulty: 'i' | 'i+1' | 'i+2';
}

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('onboarding');
  const [selectedContent, setSelectedContent] = useState<LearningContent | null>(null);
  const [userLevel, setUserLevel] = useState<number>(1);
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState(false);
  const [shouldShowExplainer, setShouldShowExplainer] = useState(false);
  const [lastExplainerDate, setLastExplainerDate] = useState<number | null>(null);
  const [lastActivityDate, setLastActivityDate] = useState<number>(Date.now());

  // Check if explainer should be shown (every 2 months with no activity)
  useEffect(() => {
    const TWO_MONTHS_MS = 60 * 24 * 60 * 60 * 1000; // ~60 days in milliseconds
    const now = Date.now();
    
    if (lastExplainerDate === null) {
      // First time user - will show after onboarding
      return;
    }
    
    const timeSinceLastExplainer = now - lastExplainerDate;
    const timeSinceLastActivity = now - lastActivityDate;
    
    if (timeSinceLastActivity > TWO_MONTHS_MS && timeSinceLastExplainer > TWO_MONTHS_MS) {
      setShouldShowExplainer(true);
    }
  }, [lastExplainerDate, lastActivityDate]);

  const handleOnboardingComplete = (level: number) => {
    setUserLevel(level);
    setHasCompletedOnboarding(true);
    setShouldShowExplainer(true);
    setCurrentScreen('explainer');
  };

  const handleExplainerComplete = () => {
    setShouldShowExplainer(false);
    setLastExplainerDate(Date.now());
    setCurrentScreen('feed');
  };

  const handleContentSelect = (content: LearningContent) => {
    setSelectedContent(content);
    setCurrentScreen('concept');
  };

  const handleBack = () => {
    setCurrentScreen('feed');
    setSelectedContent(null);
  };

  const handleNavigation = (screen: Screen) => {
    setLastActivityDate(Date.now());
    setCurrentScreen(screen);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'onboarding':
        return <OnboardingFlow onComplete={handleOnboardingComplete} />;
      case 'explainer':
        return <AdaptiveLearningExplainer onContinue={handleExplainerComplete} />;
      case 'feed':
        return <MainFeed onContentSelect={handleContentSelect} userLevel={userLevel} />;
      case 'concept':
        return <ConceptDetail content={selectedContent} onBack={handleBack} />;
      case 'flashcards':
        return <FlashcardsView onBack={() => handleNavigation('feed')} />;
      case 'upload':
        return <UploadHub 
          onBack={() => handleNavigation('feed')} 
          onUploadComplete={() => {
            setShouldShowExplainer(true);
            setCurrentScreen('explainer');
          }}
        />;
      case 'dashboard':
        return <Dashboard userLevel={userLevel} />;
      case 'social':
        return <SocialLoops />;
      case 'profile':
        return <Profile userLevel={userLevel} />;
      default:
        return <MainFeed onContentSelect={handleContentSelect} userLevel={userLevel} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {renderScreen()}
      {hasCompletedOnboarding && currentScreen !== 'onboarding' && currentScreen !== 'concept' && currentScreen !== 'explainer' && (
        <BottomNav currentScreen={currentScreen} onNavigate={handleNavigation} />
      )}
    </div>
  );
}

export default App;
